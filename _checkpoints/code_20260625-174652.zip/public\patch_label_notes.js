// patch_label_notes.js — tighten the inline spacing above the order-notes line on labels (1mm -> 0.3mm). In place.
const fs=require("fs");
const FILE="glassfab.html";
let s=fs.readFileSync(FILE,"utf8");
if(!s.startsWith("<!DOCTYPE")){ console.log("ABORT: not glassfab.html"); process.exit(1); }
if(s.indexOf("border-top:1px solid #eee;margin-top:0.3mm;padding-top:0.3mm")>=0){ console.log("Already patched. No changes."); process.exit(0); }
const OLD=Buffer.from("ICAgICAgICAgICR7b3JkLm5vdGVzP2A8ZGl2IGNsYXNzPSJsYmwtcHJvY3MiIHN0eWxlPSJib3JkZXItdG9wOjFweCBzb2xpZCAjZWVlO21hcmdpbi10b3A6MW1tO3BhZGRpbmctdG9wOjFtbSI+JHtvcmQubm90ZXN9PC9kaXY+YDonJ30=","base64").toString("utf8");
const NEW=Buffer.from("ICAgICAgICAgICR7b3JkLm5vdGVzP2A8ZGl2IGNsYXNzPSJsYmwtcHJvY3MiIHN0eWxlPSJib3JkZXItdG9wOjFweCBzb2xpZCAjZWVlO21hcmdpbi10b3A6MC4zbW07cGFkZGluZy10b3A6MC4zbW0iPiR7b3JkLm5vdGVzfTwvZGl2PmA6Jyd9","base64").toString("utf8");
const c=s.split(OLD).length-1;
if(c!==1){ console.log("ABORT - notes-line anchor matched "+c+" times (want 1), file NOT modified."); process.exit(1); }
const out=s.replace(OLD, ()=>NEW);
const bak="C:\\Users\\DELL\\Downloads\\Claude Latest\\_backups\\glassfab.pre-labelnotes-"+new Date().toISOString().replace(/[:.]/g,"-")+".html";
fs.copyFileSync(FILE,bak); fs.writeFileSync(FILE,out);
console.log("PATCHED OK | tightened:", out.includes("margin-top:0.3mm;padding-top:0.3mm"));
console.log("Backup:", bak);
