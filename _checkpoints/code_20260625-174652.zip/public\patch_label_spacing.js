// patch_label_spacing.js — tighten label info column: smaller line-height + flex gap, vertically centered.
// Reduces the inter-row white space and the empty space below the description. Print layout only. In place.
const fs=require("fs");
const FILE="glassfab.html";
let s=fs.readFileSync(FILE,"utf8");
if(!s.startsWith("<!DOCTYPE")){ console.log("ABORT: not glassfab.html"); process.exit(1); }
if(s.indexOf("#label-print-root .lbl-info{flex:1;display:flex;flex-direction:column;justify-content:center")>=0){ console.log("Already patched. No changes."); process.exit(0); }
const OLD=Buffer.from("ICBib2R5LnByaW50LWxhYmVscyAubGJsLWluZm8sCiAgI2xhYmVsLXByaW50LXJvb3QgLmxibC1pbmZve2ZsZXg6MTtkaXNwbGF5OmZsZXg7ZmxleC1kaXJlY3Rpb246Y29sdW1uO292ZXJmbG93OmhpZGRlbjttaW4td2lkdGg6MDtnYXA6MC44bW07cGFkZGluZzoxLjVtbSAybW0gMS41bW0gMS41bW07Ym94LXNpemluZzpib3JkZXItYm94O3dpZHRoOjB9","base64").toString("utf8");
const NEW=Buffer.from("ICBib2R5LnByaW50LWxhYmVscyAubGJsLWluZm8sCiAgI2xhYmVsLXByaW50LXJvb3QgLmxibC1pbmZve2ZsZXg6MTtkaXNwbGF5OmZsZXg7ZmxleC1kaXJlY3Rpb246Y29sdW1uO2p1c3RpZnktY29udGVudDpjZW50ZXI7b3ZlcmZsb3c6aGlkZGVuO21pbi13aWR0aDowO2dhcDowLjJtbTtsaW5lLWhlaWdodDoxLjE7cGFkZGluZzoxbW0gMm1tO2JveC1zaXppbmc6Ym9yZGVyLWJveDt3aWR0aDowfQ==","base64").toString("utf8");
const c=s.split(OLD).length-1;
if(c!==1){ console.log("ABORT - lbl-info anchor matched "+c+" times (want 1), file NOT modified."); process.exit(1); }
const out=s.replace(OLD, ()=>NEW);
const bak="C:\\Users\\DELL\\Downloads\\Claude Latest\\_backups\\glassfab.pre-labelspacing-"+new Date().toISOString().replace(/[:.]/g,"-")+".html";
fs.copyFileSync(FILE,bak); fs.writeFileSync(FILE,out);
console.log("PATCHED OK | tightened:", out.includes("justify-content:center;overflow:hidden;min-width:0;gap:0.2mm;line-height:1.1"));
console.log("Backup:", bak);
