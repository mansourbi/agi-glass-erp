// patch_label_fonts.js — enlarge + darken + bolden label print fonts (glass/procs/desc) for TSC thermal legibility. In place. QR/logo untouched.
const fs=require("fs");
const FILE="glassfab.html";
let s=fs.readFileSync(FILE,"utf8");
if(!s.startsWith("<!DOCTYPE")){ console.log("ABORT: not glassfab.html"); process.exit(1); }
if(s.indexOf("lbl-glass{font-family:'Cairo','DM Mono',Courier,monospace;font-size:10.5pt")>=0){ console.log("Already patched. No changes."); process.exit(0); }
const dec=b=>Buffer.from(b,"base64").toString("utf8");
const P=[
{o:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLWdsYXNzLAogICNsYWJlbC1wcmludC1yb290IC5sYmwtZ2xhc3N7Zm9udC1mYW1pbHk6J0NhaXJvJywnRE0gTW9ubycsQ291cmllcixtb25vc3BhY2U7Zm9udC1zaXplOjlwdDtjb2xvcjojNDQ0O3RleHQtYWxpZ246Y2VudGVyO2Rpc3BsYXk6YmxvY2t9",n:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLWdsYXNzLAogICNsYWJlbC1wcmludC1yb290IC5sYmwtZ2xhc3N7Zm9udC1mYW1pbHk6J0NhaXJvJywnRE0gTW9ubycsQ291cmllcixtb25vc3BhY2U7Zm9udC1zaXplOjEwLjVwdDtmb250LXdlaWdodDo2MDA7Y29sb3I6IzExMTt0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmJsb2NrfQ=="},
{o:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLXByb2NzLAogICNsYWJlbC1wcmludC1yb290IC5sYmwtcHJvY3N7Zm9udC1mYW1pbHk6J0NhaXJvJywnRE0gU2FucycsQXJpYWwsc2Fucy1zZXJpZjtmb250LXNpemU6OC41cHQ7Y29sb3I6IzU1NTt0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmJsb2NrO292ZXJmbG93OmhpZGRlbjtkaXNwbGF5Oi13ZWJraXQtYm94Oy13ZWJraXQtbGluZS1jbGFtcDoyOy13ZWJraXQtYm94LW9yaWVudDp2ZXJ0aWNhbH0=",n:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLXByb2NzLAogICNsYWJlbC1wcmludC1yb290IC5sYmwtcHJvY3N7Zm9udC1mYW1pbHk6J0NhaXJvJywnRE0gU2FucycsQXJpYWwsc2Fucy1zZXJpZjtmb250LXNpemU6MTBwdDtmb250LXdlaWdodDo2MDA7Y29sb3I6IzExMTt0ZXh0LWFsaWduOmNlbnRlcjtkaXNwbGF5OmJsb2NrO292ZXJmbG93OmhpZGRlbjtkaXNwbGF5Oi13ZWJraXQtYm94Oy13ZWJraXQtbGluZS1jbGFtcDoyOy13ZWJraXQtYm94LW9yaWVudDp2ZXJ0aWNhbH0="},
{o:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLWRlc2MsCiAgI2xhYmVsLXByaW50LXJvb3QgLmxibC1kZXNje2ZvbnQtZmFtaWx5OidDYWlybycsJ0RNIFNhbnMnLEFyaWFsLHNhbnMtc2VyaWY7Zm9udC1zaXplOjhwdDtjb2xvcjojODg4O2ZvbnQtc3R5bGU6aXRhbGljO3RleHQtYWxpZ246Y2VudGVyO2Rpc3BsYXk6YmxvY2s7b3ZlcmZsb3c6aGlkZGVuO3RleHQtb3ZlcmZsb3c6ZWxsaXBzaXM7d2hpdGUtc3BhY2U6bm93cmFwfQ==",n:"ICBib2R5LnByaW50LWxhYmVscyAubGJsLWRlc2MsCiAgI2xhYmVsLXByaW50LXJvb3QgLmxibC1kZXNje2ZvbnQtZmFtaWx5OidDYWlybycsJ0RNIFNhbnMnLEFyaWFsLHNhbnMtc2VyaWY7Zm9udC1zaXplOjEwcHQ7Zm9udC13ZWlnaHQ6NjAwO2NvbG9yOiMxMTE7dGV4dC1hbGlnbjpjZW50ZXI7b3ZlcmZsb3c6aGlkZGVuO2Rpc3BsYXk6LXdlYmtpdC1ib3g7LXdlYmtpdC1saW5lLWNsYW1wOjI7LXdlYmtpdC1ib3gtb3JpZW50OnZlcnRpY2FsfQ=="}
];
let fails=[];
for(let i=0;i<P.length;i++){ const o=dec(P[i].o); const c=s.split(o).length-1; if(c!==1) fails.push("hunk"+i+": "+c+" matches"); }
if(fails.length){ console.log("ABORT - anchors not matched, file NOT modified:"); fails.forEach(f=>console.log("  "+f)); process.exit(1); }
let out=s;
for(let i=0;i<P.length;i++){ out=out.replace(dec(P[i].o), ()=>dec(P[i].n)); }
const bak="C:\\Users\\DELL\\Downloads\\Claude Latest\\_backups\\glassfab.pre-labelfonts-"+new Date().toISOString().replace(/[:.]/g,"-")+".html";
fs.copyFileSync(FILE,bak); fs.writeFileSync(FILE,out);
console.log("PATCHED OK | glass:", out.includes("lbl-glass{font-family:'Cairo','DM Mono',Courier,monospace;font-size:10.5pt"), "| procs:", out.includes("lbl-procs{font-family:'Cairo','DM Sans',Arial,sans-serif;font-size:10pt"), "| desc:", out.includes("lbl-desc{font-family:'Cairo','DM Sans',Arial,sans-serif;font-size:10pt"));
console.log("Backup:", bak);
