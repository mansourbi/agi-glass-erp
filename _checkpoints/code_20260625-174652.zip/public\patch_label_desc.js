// patch_label_desc.js — show the piece DESCRIPTION (order's code field) LIVE from the order on each label.
// Resolves item.uid against the order item's piece_uids and uses its current code, so edits to the order
// reflect on the label without re-optimizing. Falls back to the stored label code/description.
const fs=require("fs");
const FILE="glassfab.html";
let s=fs.readFileSync(FILE,"utf8");
if(!s.startsWith("<!DOCTYPE")){ console.log("ABORT: not glassfab.html"); process.exit(1); }
if(s.indexOf("_liveCode")>=0){ console.log("Already patched. No changes."); process.exit(0); }
const OLD=Buffer.from("ICAgIGNvbnN0IF9kZXNjVmFsPShpdGVtLmRlc2NyaXB0aW9uJiZpdGVtLmRlc2NyaXB0aW9uIT09J1BDJz9pdGVtLmRlc2NyaXB0aW9uOicnKSB8fCAoaXRlbS5jb2RlJiZpdGVtLmNvZGUhPT0nUEMnP2l0ZW0uY29kZTonJyk7","base64").toString("utf8");
const NEW=Buffer.from("ICAgIGNvbnN0IF9vcmRJdGVtPShvcmQuaXRlbXN8fFtdKS5maW5kKGl0PT57Y29uc3QgX3U9aXQucGllY2VVSURzfHxpdC5waWVjZV91aWRzfHxbXTtyZXR1cm4gX3UuaW5jbHVkZXMoaXRlbS51aWQpO30pOwogICAgY29uc3QgX2xpdmVDb2RlPShfb3JkSXRlbSYmX29yZEl0ZW0uY29kZSYmX29yZEl0ZW0uY29kZSE9PSdQQycpP19vcmRJdGVtLmNvZGU6Jyc7CiAgICBjb25zdCBfZGVzY1ZhbD1fbGl2ZUNvZGUgfHwgKGl0ZW0uZGVzY3JpcHRpb24mJml0ZW0uZGVzY3JpcHRpb24hPT0nUEMnP2l0ZW0uZGVzY3JpcHRpb246JycpIHx8IChpdGVtLmNvZGUmJml0ZW0uY29kZSE9PSdQQyc/aXRlbS5jb2RlOicnKTs=","base64").toString("utf8");
const c=s.split(OLD).length-1;
if(c!==1){ console.log("ABORT - makeLabel anchor matched "+c+" times (want 1), file NOT modified."); process.exit(1); }
const out=s.replace(OLD, ()=>NEW);
const bak="C:\\Users\\DELL\\Downloads\\Claude Latest\\_backups\\glassfab.pre-labeldesc-"+new Date().toISOString().replace(/[:.]/g,"-")+".html";
fs.copyFileSync(FILE,bak); fs.writeFileSync(FILE,out);
console.log("PATCHED OK | liveDesc:", out.includes("_liveCode"));
console.log("Backup:", bak);
